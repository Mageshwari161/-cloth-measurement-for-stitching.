# Simple Clothing Store


Howdy! o(*￣▽￣*)ブ


I am the frontend that gets compiled to the production version with `npm run build` and then moved to the root folder to be hosted on a single server. I'm mostly built with React, and my fancy looks come via Bootstrap and SASS.

## I'm using
  * [React (with hooks, no classes)](https://reactjs.org/docs/hooks-intro.html)
  * [React router](https://www.npmjs.com/package/react-router)
  * [Bootstrap](https://getbootstrap.com/)
  * [SASS](https://sass-lang.com/)
  * [Moment](https://www.npmjs.com/package/moment)
  * [currency.js](https://www.npmjs.com/package/currency.js)
  * [react-paypal-button-v2](https://www.npmjs.com/package/react-paypal-button-v2)
  * [react-helmet](https://www.npmjs.com/package/react-helmet)